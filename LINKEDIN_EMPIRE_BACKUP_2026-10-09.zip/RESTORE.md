# LINKEDIN EMPIRE - OFFLINE BACKUP (Oct 9, 2026)

## Restore (any machine)
    git clone -b main linkedin_emphire_full.bundle linkedin_emphire
Verify: git log --oneline | head -3  (match COMMIT_LOG.txt top)

## Re-sync to GitHub (repo is currently 130+ commits AHEAD of the online one - push this!)
    git push https://github.com/Teamthy/linkedin_emphire.git main
Username + Personal Access Token (repo scope) when asked. Use your push_to_github.ps1 if it holds the PAT. NEVER paste PAT into chat or commit it.

## Standing habit (10 seconds): after every commit batch:
    git bundle create ~/backups/emphire_$(date +%F).bundle main
Newest bundle in ONE cloud-synced folder + email it to yourself monthly.
